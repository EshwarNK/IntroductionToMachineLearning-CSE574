from sklearn import svm
from Preprocessing import preprocess
from Report_Results import report_results
import numpy as np
from utils import *
from Postprocessing import *
from utils import *
import copy



def SVM_classification(metrics):

    training_data, training_labels, test_data, test_labels, categories, mappings = preprocess(metrics, recalculate=False, causal=False)

    np.random.seed(42)
    SVR = svm.LinearSVR(C=1.0/float(len(test_data)), max_iter=5000)
    SVR.fit(training_data, training_labels)

    data = np.concatenate((training_data, test_data))
    labels = np.concatenate((training_labels, test_labels))

    predictions = SVR.predict(data)
    return data, predictions, labels, categories, mappings

#######################################################################################################################

metrics = ["sex", "age_cat", 'race', 'c_charge_degree', 'priors_count']

data, predictions, labels, categories, mappings = SVM_classification(metrics)
race_cases = get_cases_by_metric(data, categories, "race", mappings, predictions, labels)


#######################################################################################################################

print("Attempting to enforce predictive parity...")
predictive_parity_data, predictive_parity_thresholds = enforce_predictive_parity(copy.deepcopy(race_cases), 0.01)
if predictive_parity_data is not None:
    print("--------------------PREDICTIVE PARITY RESULTS--------------------")
    print("")
    for group in predictive_parity_data.keys():
        accuracy = get_num_correct(predictive_parity_data[group]) / len(predictive_parity_data[group])
        print("Accuracy for " + group + ": " + str(accuracy))

    print("")
    for group in predictive_parity_data.keys():
        PPV = get_positive_predictive_value(predictive_parity_data[group])
        print("PPV for " + group + ": " + str(PPV))

    print("")
    for group in predictive_parity_data.keys():
        FPR = get_false_positive_rate(predictive_parity_data[group])
        print("FPR for " + group + ": " + str(FPR))

    print("")
    for group in predictive_parity_data.keys():
        FNR = get_false_negative_rate(predictive_parity_data[group])
        print("FNR for " + group + ": " + str(FNR))

    print("")
    for group in predictive_parity_data.keys():
        TPR = get_true_positive_rate(predictive_parity_data[group])
        print("TPR for " + group + ": " + str(TPR))

    print("")
    for group in predictive_parity_data.keys():
        TNR = get_true_negative_rate(predictive_parity_data[group])
        print("TNR for " + group + ": " + str(TNR))

    print("")
    for group in predictive_parity_thresholds.keys():
        print("Threshold for " + group + ": " + str(predictive_parity_thresholds[group]))

    print("")
    total_cost = apply_financials(predictive_parity_data)
    print("Total cost: ")
    print('${:,.0f}'.format(total_cost))
    total_accuracy = get_total_accuracy(predictive_parity_data)
    print("Total accuracy: " + str(total_accuracy))
    print("-----------------------------------------------------------------")
    print("")

#######################################################################################################################